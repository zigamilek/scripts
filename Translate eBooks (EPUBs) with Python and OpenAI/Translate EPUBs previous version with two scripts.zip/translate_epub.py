#!/usr/bin/env python3
"""
translate_epub.py

Usage:
    python translate_epub.py -i input.epub -o output.epub [options]

Options:
    -i INPUT_EPUB, --input_epub INPUT_EPUB        Path to the input EPUB file (required)
    -o OUTPUT_EPUB, --output_epub OUTPUT_EPUB     Path for the output translated EPUB file (required)
    --model MODEL        OpenAI model to use for translation (default: chatgpt-4o-latest)
    --chunk_size N       Maximum tokens per translation chunk (default: 2000)
    --test_chunk         Process only the first chunk and exit (test mode)
    --export_html_dir DIR    Directory to write translated HTML chapters to (optional)

Environment:
    Set OPENAI_API_KEY to your OpenAI API key.

This script translates an EPUB from English to Slovenian using OpenAI's API,
processing content in chunks to respect the context window and retaining HTML formatting.
"""
import os
import sys
import argparse

# Core dependencies
import openai
from ebooklib import epub
from ebooklib.epub import EpubException, EpubImage
from bs4 import BeautifulSoup
import tiktoken
from pathlib import Path

def chunk_html(html, encoder, max_tokens):
    """Split HTML content into chunks of <= max_tokens based on block tags."""
    soup = BeautifulSoup(html, 'html.parser')
    body = soup.body or soup
    blocks = [str(tag) for tag in body.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'li', 'blockquote'])]
    if not blocks:
        blocks = [html]
    chunks = []
    current_chunk = ''
    current_tokens = 0
    for block in blocks:
        block_tokens = len(encoder.encode(block))
        if block_tokens > max_tokens:
            chunks.append(block)
            continue
        if current_tokens + block_tokens > max_tokens:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = block
            current_tokens = block_tokens
        else:
            current_chunk += block
            current_tokens += block_tokens
    if current_chunk:
        chunks.append(current_chunk)
    return chunks

def translate_chunk(chunk, model):
    """Translate an HTML chunk from English to Slovenian, preserving HTML tags."""
    messages = [
        {"role": "system", "content": "You are a translator that translates children books (ages 8 to 15) from English to Slovenian. The content you get is HTML content. Preserve all HTML tags and attributes and return only the translated HTML."},
        {"role": "user", "content": chunk}
    ]
    response = openai.chat.completions.create(
        model=model,
        messages=messages
    )
    return response.choices[0].message.content

def parse_args():
    parser = argparse.ArgumentParser(
        description="Translate an EPUB ebook from English to Slovenian using OpenAI."
    )
    parser.add_argument(
        "-i", "--input_epub", required=True, help="Path to the input EPUB file"
    )
    parser.add_argument(
        "-o", "--output_epub", required=True, help="Path for the output translated EPUB file"
    )
    parser.add_argument(
        "--model", default="chatgpt-4o-latest", help="OpenAI model to use for translation"
    )
    parser.add_argument(
        "--chunk_size", type=int, default=2000, help="Maximum tokens per translation chunk"
    )
    parser.add_argument(
        "--test_chunk", action="store_true", help="Process only the first chunk and exit (test mode)"
    )
    parser.add_argument(
        "--export_html_dir", help="Directory to write translated HTML chapters to (optional)"
    )
    return parser.parse_args()

def main():
    args = parse_args()
    test_mode = args.test_chunk  # Flag to run only one chunk for test
    #api_key = os.getenv("OPENAI_API_KEY")
    api_key = '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'
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable not set.")
        sys.exit(1)
    openai.api_key = api_key

    # Prepare export directory if needed
    export_dir = args.export_html_dir
    if export_dir:
        export_dir = Path(export_dir)
        export_dir.mkdir(parents=True, exist_ok=True)

    try:
        book = epub.read_epub(args.input_epub)
    except EpubException:
        print(f"Error: could not parse EPUB file '{args.input_epub}'. Ensure it is a valid EPUB. Consider converting with Calibre.")
        sys.exit(1)

    if export_dir:
        images_dir = export_dir / 'images'
        images_dir.mkdir(parents=True, exist_ok=True)
        for img_item in book.get_items():
            if isinstance(img_item, EpubImage):
                data = img_item.get_content()
                fname = os.path.basename(img_item.file_name)
                with open(images_dir / fname, 'wb') as img_f:
                    img_f.write(data)
        print(f"Exported images to {images_dir}")

    html_items = [item for item in book.get_items() if isinstance(item, epub.EpubHtml)]
    if not html_items:
        print("No HTML documents found in EPUB.")
        sys.exit(1)

    try:
        encoder = tiktoken.encoding_for_model(args.model)
    except KeyError:
        print(f"Warning: could not map model '{args.model}' to a tokenizer, falling back to cl100k_base encoding.")
        encoder = tiktoken.get_encoding("cl100k_base")

    for idx, item in enumerate(html_items):
        html = item.get_content().decode('utf-8')
        chunks = chunk_html(html, encoder, args.chunk_size)
        print(f"Processing document {item.get_id()} split into {len(chunks)} chunks")
        translated_chunks = []
        for i, chunk in enumerate(chunks):
            print(f"Translating chunk {i+1}/{len(chunks)}")
            translated = translate_chunk(chunk, args.model)
            translated_chunks.append(translated)
            if test_mode:
                break
        new_html = ''.join(translated_chunks)
        if export_dir:
            # Write each translated chapter as HTML file using original EPUB file names
            soup = BeautifulSoup(new_html, 'html.parser')
            # Adjust image sources to point to the images folder
            for img in soup.find_all('img'):
                src = img.get('src')
                if src:
                    img['src'] = f"images/{os.path.basename(src)}"
            # Use original EPUB HTML filename (stem) for export
            orig_stem = Path(item.file_name).stem  # e.g., 'chapter1'
            filename = f"{orig_stem}.html"
            path = export_dir / filename
            with open(path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"Written chapter to {path}")
        else:
            item.set_content(new_html.encode('utf-8'))

    if export_dir:
        print(f"All chapters written to HTML in {export_dir}")
    else:
        epub.write_epub(args.output_epub, book)
        print(f"Translated EPUB saved to {args.output_epub}")

if __name__ == "__main__":
    main()
