#!/usr/bin/env python3
"""
build_epub_from_html.py

Usage:
    python build_epub_from_html.py -i input_dir -o output.epub [options]

Options:
    -i INPUT_DIR, --input_dir INPUT_DIR    Directory with numbered HTML chapter files
    -o OUTPUT_EPUB, --output_epub OUTPUT_EPUB    Path for the generated EPUB file
    --title TITLE                          (Optional) Book title metadata
    --author AUTHOR                        (Optional) Book author metadata

This script reads all .html files in INPUT_DIR in sorted order,
wraps each as an EPUB chapter, assembles a table of contents and spine,
and writes the resulting EPUB.
"""
import sys
import argparse
from pathlib import Path
from ebooklib import epub
import mimetypes
from bs4 import BeautifulSoup
from ebooklib.epub import EpubImage
from ebooklib.epub import EpubException
import re

def parse_args():
    parser = argparse.ArgumentParser(
        description="Build an EPUB from a directory of HTML chapter files."
    )
    parser.add_argument(
        "-i", "--input_dir", required=True,
        help="Directory containing chapter HTML files"
    )
    parser.add_argument(
        "-o", "--output_epub", required=True,
        help="Output EPUB file path"
    )
    parser.add_argument(
        "--title", default=None,
        help="Book title (optional)"
    )
    parser.add_argument(
        "--author", default=None,
        help="Book author (optional)"
    )
    parser.add_argument(
        "--source_epub", help="Original EPUB file to copy metadata from (optional)"
    )
    return parser.parse_args()

def main():
    args = parse_args()
    input_dir = Path(args.input_dir)
    if not input_dir.is_dir():
        print(f"Error: '{input_dir}' is not a directory.")
        sys.exit(1)

    html_files = sorted(input_dir.glob("*.html"))
    if not html_files:
        print(f"No HTML files found in {input_dir}.")
        sys.exit(1)

    # Initialize new EPUB
    book = epub.EpubBook()
    # If a source EPUB is provided, copy metadata
    if args.source_epub:
        try:
            src = epub.read_epub(args.source_epub)
        except EpubException:
            print(f"Error: could not parse source EPUB '{args.source_epub}'.")
            sys.exit(1)
        # Copy title if not overridden
        if args.title is None and src.title:
            book.set_title(src.title)
        # Copy authors if not overridden
        if args.author is None:
            for creator, attrs in src.get_metadata('DC', 'creator'):
                book.add_author(creator)
        # Copy identifiers
        for ident, attrs in src.get_metadata('DC', 'identifier'):
            book.set_identifier(ident)
        # Copy language
        for lang, attrs in src.get_metadata('DC', 'language'):
            book.set_language(lang)
        # Copy publishers
        for pub, attrs in src.get_metadata('DC', 'publisher'):
            book.add_metadata('DC', 'publisher', pub)
        # Copy comments/description for Calibre's Comments field
        for desc, attrs in src.get_metadata('DC', 'description'):
            book.add_metadata('DC', 'description', desc)

    # Copy images from HTML export directory
    images_dir = Path(args.input_dir) / 'images'
    if images_dir.is_dir():
        added = 0
        for img_file in images_dir.iterdir():
            if img_file.is_file():
                data = img_file.read_bytes()
                mime, _ = mimetypes.guess_type(img_file.name)
                mime = mime or 'application/octet-stream'
                img_item = epub.EpubImage()
                img_item.file_name = f"images/{img_file.name}"
                img_item.media_type = mime
                img_item.content = data
                book.add_item(img_item)
                added += 1
        print(f"Added {added} images from {images_dir} to EPUB")
    # Copy cover image and extract original TOC titles from source EPUB
    orig_titles = []
    if args.source_epub:
        # Flatten original TOC entries to preserve ordering and titles
        def flatten_toc(entries):
            flattened = []
            for entry in entries or []:
                if isinstance(entry, (list, tuple)):
                    flattened.extend(flatten_toc(entry))
                else:
                    if hasattr(entry, 'title'):
                        flattened.append(entry)
            return flattened
        orig_entries = flatten_toc(src.toc)
        orig_titles = [e.title for e in orig_entries]
        # Copy cover image
        if args.source_epub:
            # Attempt to copy cover via metadata
            cover_set = False
            cov_meta = src.get_metadata('OPF', 'cover')
            if cov_meta:
                _, attrs = cov_meta[0]
                cover_id = attrs.get('content')
                if cover_id:
                    cover_item = src.get_item_with_id(cover_id)
                    if cover_item:
                        book.set_cover(cover_item.file_name, cover_item.get_content())
                        cover_set = True
            # Fallback: find any image with 'cover' in filename
            if not cover_set:
                for itm in src.get_items():
                    if isinstance(itm, EpubImage) and 'cover' in itm.file_name.lower():
                        book.set_cover(itm.file_name, itm.get_content())
                        cover_set = True
                        break
            if cover_set:
                print("Cover image copied from source EPUB.")

    if args.title:
        book.set_title(args.title)
    if args.author:
        book.add_author(args.author)

    chapters = []
    for idx, html_file in enumerate(html_files):
        content = html_file.read_text(encoding='utf-8')
        soup = BeautifulSoup(content, 'html.parser')
        title = soup.title.string if soup.title else html_file.stem
        # Wrap fragment in full XHTML if missing <html> tag
        if '<html' not in content.lower():
            full_content = (
                '<?xml version="1.0" encoding="utf-8"?>\n'
                '<html xmlns="http://www.w3.org/1999/xhtml">\n'
                '<head><title>' + title + '</title></head>\n'
                '<body>\n' + content + '\n</body>\n'
                '</html>'
            )
        else:
            full_content = content
        chap = epub.EpubHtml(
            title=title,
            file_name=f"chap_{idx+1:03d}.xhtml",
            lang="sl"
        )
        # Set chapter content as UTF-8 bytes
        chap.content = full_content.encode('utf-8')
        # Override get_body_content to strip XML declaration and return bytes for nav generation
        stripped = re.sub(r'^<\\?xml[^>]+\\?>', '', full_content).lstrip()
        chap.get_body_content = lambda content_bytes=stripped: content_bytes.encode('utf-8')
        book.add_item(chap)
        chapters.append(chap)

    # Build table of contents and spine
    if args.source_epub:
        # Build mapping of original file hrefs to titles
        toc_map = {}
        def flatten(entries):
            for nav in entries:
                if isinstance(nav, (list, tuple)):
                    link, children = nav
                    href = link.href.split('#')[0]
                    toc_map[href] = link.title
                    flatten(children)
                else:
                    href = nav.href.split('#')[0]
                    toc_map[href] = nav.title
        flatten(src.toc or [])
        # Use Link objects for TOC with preserved titles
        toc = []
        for chap in chapters:
            title = toc_map.get(chap.file_name, chap.title)
            toc.append(epub.Link(chap.file_name, title, chap.file_name))
        book.toc = toc
    else:
        book.toc = chapters
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    # Exclude nav.xhtml from reading order so book opens at first chapter
    book.spine = chapters

    # Debug: inspect chapter contents before writing
    print("Debug: Chapter content summary:")
    for chap in chapters:
        content = chap.content
        content_str = content.decode('utf-8', errors='ignore') if isinstance(content, (bytes, bytearray)) else content
        has_body = '<body' in content_str.lower()
        print(f"  {chap.file_name}: length={len(content_str)}, has_body={has_body}")
    # Debug: verify get_body_content for each chapter
    print("Debug: Verifying get_body_content for each chapter...")
    for chap in chapters:
        try:
            body = chap.get_body_content()
            print(f"  {chap.file_name}: body length={len(body)}")
        except Exception as e:
            print(f"Error parsing body for {chap.file_name}: {e}")
            sys.exit(1)

    epub.write_epub(args.output_epub, book)
    print(f"EPUB created at {args.output_epub}")

if __name__ == "__main__":
    main()
